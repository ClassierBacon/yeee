# Silent Gear Calculator #

A web-based optimization/calculation tool for the Minecraft mod Silent Gear.

<!-- omit in toc -->
## Table of Contents ##

* [Silent Gear Calculator](#silent-gear-calculator)
    * [License](#license)

## License ##

Copyright (c) 2024 G'lek Tarssza

All rights reserved.
