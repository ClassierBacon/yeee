declare module 'pug-plugin' {
    import {Compiler} from 'webpack';

    export class PugPlugin {
        /**
         * The Webpack loader.
         */
        static loader: string;

        /**
         * Create a new instance.
         *
         * @param options - The options to configure the new instance with.
         */
        constructor(options: unknown);

        /**
         * Apply the plugin instance to the given Webpack compiler.
         *
         * @param compiler - The compiler to apply the plugin instance to.
         */
        apply(compiler: Compiler): void;
    }

    export default PugPlugin;
}
