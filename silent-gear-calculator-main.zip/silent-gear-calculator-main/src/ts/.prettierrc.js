const parent = require('../../.prettierrc');

module.exports = {
    ...parent
};
