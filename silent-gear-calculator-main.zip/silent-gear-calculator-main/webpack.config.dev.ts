//-- NodeJS
import path from 'node:path';

//-- NPM Packages
import ForkTSCheckerWebpackPlugin from 'fork-ts-checker-webpack-plugin';
import PugPlugin from 'pug-plugin';
import {Configuration} from 'webpack';
import 'webpack-dev-server';
import webpackMerge from 'webpack-merge';

//-- Project Code
import './pug-plugin';
import common from './webpack.config.common';

/**
 * The development environment Webpack configuration.
 */
export const config: Configuration = webpackMerge(common, {
    name: 'dev',
    mode: 'development',
    devtool: 'inline-source-map',
    devServer: {
        hot: false,
        liveReload: false,
        port: 8080
    },
    resolve: {},
    entry: './src/index.pug',
    output: {
        clean: true,
        path: path.resolve(__dirname, './dist/dev/')
    },
    module: {
        rules: []
    },
    plugins: [
        {
            apply(compiler) {
                const logger = compiler.getInfrastructureLogger(
                    'vscode-background-task'
                );
                compiler.hooks.beforeCompile.tap(
                    'vscode-background-task',
                    () => {
                        logger.info('Starting to compile...');
                    }
                );
                compiler.hooks.done.tap('vscode-background-task', () => {
                    logger.info('Compile completed');
                });
            }
        },
        new PugPlugin({
            pretty: true,
            js: {
                filename: 'js/app.[contenthash].js'
            },
            css: {
                filename: 'css/app.[contenthash].css'
            }
        }),
        new ForkTSCheckerWebpackPlugin({
            async: true,
            devServer: true,
            typescript: {
                configFile: path.resolve(__dirname, './src/ts/tsconfig.json')
            }
        })
    ]
});

export default config;
