//-- NodeJS
import path from 'node:path';

//-- NPM Packages
import ForkTSCheckerWebpackPlugin from 'fork-ts-checker-webpack-plugin';
import PugPlugin from 'pug-plugin';
import {Configuration} from 'webpack';
import webpackMerge from 'webpack-merge';

//-- Project Code
import './pug-plugin';
import common from './webpack.config.common';

/**
 * The development environment Webpack configuration.
 */
export const config: Configuration = webpackMerge(common, {
    name: 'prod',
    mode: 'production',
    devtool: 'hidden-source-map',
    resolve: {},
    entry: './src/index.pug',
    output: {
        clean: true,
        path: path.resolve(__dirname, './dist/prod/'),
        filename: 'js/app.[contenthash].min.js'
    },
    module: {
        rules: []
    },
    plugins: [
        new PugPlugin({
            pretty: false,
            js: {
                filename: 'js/app.[contenthash].min.js'
            },
            css: {
                filename: 'css/app.[contenthash].min.css'
            }
        }),
        new ForkTSCheckerWebpackPlugin({
            async: true,
            devServer: true,
            typescript: {
                configFile: path.resolve(__dirname, './src/ts/tsconfig.json')
            }
        })
    ]
});

export default config;
